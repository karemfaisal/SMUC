... readme.txt kommt noch das ist ein Ausschnitt aus einer e-mail:

Bei dem "FAS-Decompiler" handelt es sich um einen Resource-Decrypter welcher die Strings in einer Fas-Datei entschl�sselt und diese wieder in die Fas-Datei zur�ckschreibt. Die entschl�sselte Fas-Datei kann nach wie vor in AutoCAD ausgef�hrt werden. ...und wird jetzt auch einige Millisekunden schneller geladen. :) (->"LPD_JUL-02.zip")

Vor einiger Zeit hab ich mit der Entwicklung einer Art Fas- Disassembler begonnen. Ich habe dem Fas-Decrypter Quelltext fast komplett neugeschrieben weil dieser "nur so schnell zusammengeschustert" war und keine gut Basis f�r Erweiterungen bot. Der Fas-Interpreter befindet sich noch im Alpha-Stadium und ist nicht f�r den Gebrauch gedacht. Zum Weiterprogrammieren sollte der Quelltext aber unbedingt dem der "alten" Version vorgezogen werden.
(->"Fas-interpreter_alpha.ace")

Leider liegt das Projekt aus Ermanglung von Zeit f�r unbestimmte Zeit "auf Eis". Desweitern hab ich auch zurzeit keinen Bedarf f�r einen Fas-Decompiler. 

Ein paar Wort �ber das Fas-Fileformat:
Das Fas-Fileformat kann man wohl eher mit einem platzsparenden Format f�r lsp-Datei vergleichen. Es umfasst 110 Befehle. Alle vorkommende Lispbefehle (z.b. ALERT,IF...) und Strings werden als Strings gespeichert und mit einem Index versehen. Wenn sie an entsprechender Stelle gebraucht werden, wird der Index verwendet und dadurch eine doppelte Speicherung vermieden. Ganze Zahlen werden als Bin�rzahl gespeichert usw...
(->"Lpd_aug-02.ace")

F�r eine Decompilierung bestehen nach meinem heutigen Kenntnis Stand gute Chancen. Bis da hin bedarf es neben reverse engineering auch einiger Programmierarbeit. Wenn du schon einige e-mail Adressen von Leuten hast, die es versucht haben und gescheitert sind w�hre ich dir sehr dankbar wenn du sie mir geben k�nntest und ich dem ein oder anderen den richtigen Weg zeigen kann. (und dieser dann die Programmierung und die ganzen l�stigen Details erledigt)
