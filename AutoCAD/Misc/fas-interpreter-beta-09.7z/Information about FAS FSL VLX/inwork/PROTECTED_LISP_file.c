int __thiscall Dec_PROTECTED_LISP_file(void *this)
{
  FILE *hFile; // eax@1
  const char **this1; // ebp@1
  int result; // eax@2
  FILE *hOut; // edi@5
  unsigned __int8 Key; // bl@7
  unsigned __int8 In_H; // al@8
  char Out; // cl@10
  int KeyTmp; // eax@15
  unsigned __int8 Out; // [sp+Ch] [bp-28h]@10
  char DstBuf; // [sp+14h] [bp-20h]@3

  this1 = (const char **)this;

  hFile = fopen(this1[25], "rb");
  if ( hFile )
  {
    fread(&DstBuf, 0x1Eu, 1u, hFile);
    if ( strncmp(&DstBuf, "AutoCAD PROTECTED LISP file\r\n\x1A", 0x1Eu) )
    {
      result = MSGRes(3, 2, 64);
    }
    else
    {
      hOut = fopen(this1[24], "wb");
      if ( hOut )
      {
        Key = getc(hFile);
        while ( !(hFile->_flag & 0x10) )
        {
          In_H = fgetc(hFile);
          if ( In_H == 0x1A )
            break;
			
          if ( In_H != 0xD )
          {
            Out = Key ^ In_H;
            if ( Out == 0xD || Out == 0x1A )
            {
              Out = In_H;
            }
            if ( Out == 0xA )
              putc(0xDu, hOut);
			  
            putc(Out, hOut);
			
            KeyTmp = 2 * In_H;
            if ( KeyTmp > 255 )
              KeyTmp -= 255;
            Key = KeyTmp;
          }
        }
        fclose(hFile);
		
        putc(0x1Au, hOut);
		
        fclose(hOut);
		
        result = MSGRes(5, 2, 64);
      }
      else
      {
        result = MSGRes(4, 2, 64);
      }
    }
  }
  else
  {
    result = MSGRes(1, 2, 64);
  }
  return result;
}